package observer;

/**
 * Interface d'un observer
 * 
 * @author Fred Simard | ETS
 * @version H2025
 */

public interface MonObserver {

	public void avertir();
	
}
